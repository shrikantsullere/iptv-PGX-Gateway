export { default } from './GenericProcessorPage';
